terraform {
  backend "local" {
    path = "/home/coder/.local/share/code-server/User/-674748394107-us-east-1-terraform-state.state"
  }
}
